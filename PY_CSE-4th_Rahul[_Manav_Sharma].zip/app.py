#!/usr/bin/env python3
"""
Personal Tracker CLI - Your All-in-One Life Management System
A comprehensive terminal-based tracker for habits, goals, health, learning, and more.
"""

import json
import os
import sys
import time
from datetime import datetime, timedelta
from collections import defaultdict
import shutil
import re

# ============================================================
# CONFIGURATION & CONSTANTS
# ============================================================

VERSION = "1.0.0"
DATA_FILE = "data.json"
BACKUP_DIR = "backup"
ARCHIVE_FILE = "archive.json"
LOG_FILE = "log.txt"
MAX_BACKUPS = 10

# Enhanced color codes for terminal output
COLORS = {
    'HEADER': '\033[95m',
    'BLUE': '\033[94m',
    'CYAN': '\033[96m',
    'GREEN': '\033[92m',
    'YELLOW': '\033[93m',
    'RED': '\033[91m',
    'MAGENTA': '\033[35m',
    'WHITE': '\033[97m',
    'BOLD': '\033[1m',
    'UNDERLINE': '\033[4m',
    'BLINK': '\033[5m',
    'BG_BLUE': '\033[44m',
    'BG_GREEN': '\033[42m',
    'BG_CYAN': '\033[46m',
    'BG_MAGENTA': '\033[45m',
    'END': '\033[0m'
}

# Gradient colors for animations
GRADIENT = [
    '\033[38;5;201m',  # Magenta
    '\033[38;5;200m',  # Pink
    '\033[38;5;199m',  # Light Pink
    '\033[38;5;198m',  # Lighter Pink
    '\033[38;5;197m',  # Very Light Pink
    '\033[38;5;163m',  # Purple
    '\033[38;5;129m',  # Blue Purple
    '\033[38;5;93m',   # Dark Purple
]

# Enhanced emojis and icons
ICONS = {
    'learning': '🎓', 'project': '🧩', 'reading': '📚',
    'fitness': '🏃', 'diet': '🍎', 'sleep': '💤', 'mood': '🧘',
    'goal': '🧭', 'time': '⏱', 'event': '📅',
    'expense': '💸', 'income': '💰', 'savings': '🪙', 'shopping': '🛒',
    'journal': '🗓', 'gratitude': '🧠',
    'bug': '💻', 'snippet': '⚙️', 'interview': '🚀',
    'habit': '✨', 'task': '✅',
    'star': '⭐', 'fire': '🔥', 'rocket': '🚀', 'sparkles': '✨',
    'trophy': '🏆', 'medal': '🏅', 'target': '🎯', 'lightning': '⚡',
    'check': '✓', 'cross': '✗', 'arrow': '→', 'bullet': '•'
}

# Enhanced motivational quotes
QUOTES = [
    "The secret of getting ahead is getting started. - Mark Twain",
    "Small progress is still progress. Keep going! 💪",
    "Success is the sum of small efforts repeated day in and day out. ⭐",
    "Your only limit is you. Break through it! 🚀",
    "Dream big, start small, act now. 🎯",
    "Discipline is choosing between what you want now and what you want most.",
    "Every expert was once a beginner. Keep learning! 📚",
    "The best time to start was yesterday. The next best time is now. ⏰",
    "You are capable of amazing things! 🌟",
    "Progress, not perfection. 💫"
]

# ASCII Art Frames
LOADING_FRAMES = [
    "⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"
]

ROCKET_FRAMES = [
    "🚀        ",
    " 🚀       ",
    "  🚀      ",
    "   🚀     ",
    "    🚀    ",
    "     🚀   ",
    "      🚀  ",
    "       🚀 ",
    "        🚀",
]

STAR_ANIMATION = [
    "✦ ✧ ✦ ✧ ✦",
    "✧ ✦ ✧ ✦ ✧",
    "✦ ✧ ✦ ✧ ✦",
    "✧ ✦ ✧ ✦ ✧",
]

# Tracker definitions
TRACKERS = {
    'learning': {'name': 'Learning Tracker', 'fields': ['subject', 'topic', 'hours', 'status'], 'icon': '🎓'},
    'project': {'name': 'Project Tracker', 'fields': ['name', 'type', 'progress', 'deadline', 'status'], 'icon': '🧩'},
    'reading': {'name': 'Reading Tracker', 'fields': ['title', 'author', 'pages', 'status', 'rating'], 'icon': '📚'},
    'fitness': {'name': 'Fitness Tracker', 'fields': ['activity', 'duration', 'calories', 'date'], 'icon': '🏃'},
    'diet': {'name': 'Diet/Meal Tracker', 'fields': ['meal', 'type', 'calories', 'mood'], 'icon': '🍎'},
    'sleep': {'name': 'Sleep Tracker', 'fields': ['date', 'hours', 'quality', 'notes'], 'icon': '💤'},
    'mood': {'name': 'Mood Tracker', 'fields': ['date', 'mood', 'notes'], 'icon': '🧘'},
    'goal': {'name': 'Goal Tracker', 'fields': ['goal', 'deadline', 'progress', 'category'], 'icon': '🧭'},
    'time': {'name': 'Time Tracker', 'fields': ['task', 'duration', 'category', 'focus'], 'icon': '⏱'},
    'event': {'name': 'Event Tracker', 'fields': ['event', 'date', 'time', 'reminder', 'notes'], 'icon': '📅'},
    'expense': {'name': 'Expense Tracker', 'fields': ['description', 'amount', 'category', 'date'], 'icon': '💸'},
    'income': {'name': 'Income Tracker', 'fields': ['source', 'amount', 'date', 'notes'], 'icon': '💰'},
    'savings': {'name': 'Savings/Budget Tracker', 'fields': ['month', 'budget', 'spent', 'saved', 'goal_status'], 'icon': '🪙'},
    'shopping': {'name': 'Shopping List', 'fields': ['item', 'category', 'priority', 'purchased'], 'icon': '🛒'},
    'journal': {'name': 'Daily Journal', 'fields': ['date', 'title', 'reflection'], 'icon': '🗓'},
    'gratitude': {'name': 'Gratitude Tracker', 'fields': ['date', 'entry', 'mood'], 'icon': '🧠'},
    'bug': {'name': 'Bug Tracker', 'fields': ['bug', 'project', 'status', 'severity', 'fix_date'], 'icon': '💻'},
    'snippet': {'name': 'Code Snippet Tracker', 'fields': ['title', 'language', 'tags', 'snippet'], 'icon': '⚙️'},
    'interview': {'name': 'Interview Prep Tracker', 'fields': ['company', 'topic', 'attempts', 'result', 'notes'], 'icon': '🚀'},
    'habit': {'name': 'Habit Tracker', 'fields': ['habit', 'date', 'completed', 'notes'], 'icon': '✨'},
    'task': {'name': 'Task Tracker', 'fields': ['task', 'priority', 'status', 'deadline', 'notes'], 'icon': '✅'}
}

# ============================================================
# ANIMATION & VISUAL FUNCTIONS
# ============================================================

def loading_animation(message="Loading", duration=1.5):
    """Display loading animation"""
    end_time = time.time() + duration
    i = 0
    while time.time() < end_time:
        frame = LOADING_FRAMES[i % len(LOADING_FRAMES)]
        sys.stdout.write(f'\r{COLORS["CYAN"]}{frame} {message}...{COLORS["END"]}')
        sys.stdout.flush()
        time.sleep(0.1)
        i += 1
    sys.stdout.write('\r' + ' ' * 50 + '\r')
    sys.stdout.flush()

def rocket_launch():
    """Animated rocket launch"""
    for frame in ROCKET_FRAMES:
        sys.stdout.write(f'\r{COLORS["YELLOW"]}{frame}{COLORS["END"]}')
        sys.stdout.flush()
        time.sleep(0.1)
    print()

def sparkle_text(text, delay=0.03):
    """Print text with sparkle effect"""
    colors = [COLORS['CYAN'], COLORS['MAGENTA'], COLORS['YELLOW'], COLORS['GREEN']]
    for i, char in enumerate(text):
        color = colors[i % len(colors)]
        sys.stdout.write(f"{color}{char}{COLORS['END']}")
        sys.stdout.flush()
        time.sleep(delay)
    print()

def rainbow_border(width=70):
    """Create rainbow colored border"""
    colors = ['\033[38;5;196m', '\033[38;5;208m', '\033[38;5;226m', 
              '\033[38;5;46m', '\033[38;5;21m', '\033[38;5;93m']
    border = ""
    for i in range(width):
        color = colors[i % len(colors)]
        border += f"{color}═{COLORS['END']}"
    return border

def pulse_text(text, times=3):
    """Make text pulse"""
    for _ in range(times):
        print(f"\r{COLORS['BOLD']}{COLORS['CYAN']}{text}{COLORS['END']}", end='', flush=True)
        time.sleep(0.3)
        print(f"\r{COLORS['CYAN']}{text}{COLORS['END']}", end='', flush=True)
        time.sleep(0.3)
    print()

def typing_effect(text, delay=0.05):
    """Simulate typing effect"""
    for char in text:
        sys.stdout.write(f"{COLORS['GREEN']}{char}{COLORS['END']}")
        sys.stdout.flush()
        time.sleep(delay)
    print()

def success_animation(message):
    """Show success with animation"""
    print(f"\n{COLORS['GREEN']}{COLORS['BOLD']}{'═' * 70}{COLORS['END']}")
    print(f"{COLORS['GREEN']}{'  ' * 15}✓ SUCCESS ✓{COLORS['END']}")
    print(f"{COLORS['GREEN']}{COLORS['BOLD']}{'═' * 70}{COLORS['END']}")
    typing_effect(f"  {message}", 0.03)
    print(f"{COLORS['GREEN']}{COLORS['BOLD']}{'═' * 70}{COLORS['END']}\n")
    time.sleep(0.5)

def error_animation(message):
    """Show error with animation"""
    print(f"\n{COLORS['RED']}{COLORS['BOLD']}{'═' * 70}{COLORS['END']}")
    print(f"{COLORS['RED']}{'  ' * 15}✗ ERROR ✗{COLORS['END']}")
    print(f"{COLORS['RED']}{COLORS['BOLD']}{'═' * 70}{COLORS['END']}")
    print(f"{COLORS['RED']}  {message}{COLORS['END']}")
    print(f"{COLORS['RED']}{COLORS['BOLD']}{'═' * 70}{COLORS['END']}\n")
    time.sleep(0.5)

# ============================================================
# MAIN TRACKER CLASS
# ============================================================

class PersonalTracker:
    def __init__(self):
        self.data = self.load_data()
        self.settings = self.data.get('settings', {'theme': 'default', 'user': 'User'})
        self.undo_stack = []
        self.ensure_directories()
        
    def ensure_directories(self):
        """Create necessary directories if they don't exist"""
        os.makedirs(BACKUP_DIR, exist_ok=True)
        
    def colorize(self, text, color='END'):
        """Add color to text if theme supports it"""
        if self.settings.get('theme') == 'no-color':
            return text
        return f"{COLORS.get(color, '')}{text}{COLORS['END']}"
    
    def log_action(self, action):
        """Log all actions to file with timestamp"""
        try:
            with open(LOG_FILE, 'a', encoding='utf-8') as f:
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                f.write(f"[{timestamp}] {action}\n")
        except Exception:
            pass
    
    def load_data(self):
        """Load data from JSON file with error recovery"""
        if not os.path.exists(DATA_FILE):
            return self._create_default_data()
        
        try:
            with open(DATA_FILE, 'r', encoding='utf-8') as f:
                data = json.load(f)
                return data
        except json.JSONDecodeError:
            print(self.colorize("⚠️  Data file corrupted. Attempting recovery...", 'YELLOW'))
            return self._recover_from_backup()
        except Exception as e:
            print(self.colorize(f"⚠️  Error loading data: {e}", 'RED'))
            return self._create_default_data()
    
    def _create_default_data(self):
        """Create default data structure"""
        data = {'settings': {'theme': 'default', 'user': 'User'}}
        for tracker in TRACKERS.keys():
            data[tracker] = []
        return data
    
    def _recover_from_backup(self):
        """Recover data from latest backup"""
        try:
            backups = sorted([f for f in os.listdir(BACKUP_DIR) if f.endswith('.json')])
            if backups:
                latest_backup = os.path.join(BACKUP_DIR, backups[-1])
                with open(latest_backup, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                success_animation("Data recovered from backup!")
                return data
        except Exception:
            pass
        return self._create_default_data()
    
    def save_data(self, create_backup=True):
        """Save data to JSON file with auto-backup"""
        try:
            if create_backup:
                self.create_backup()
            
            with open(DATA_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            error_animation(f"Error saving data: {e}")
            return False
    
    def create_backup(self):
        """Create timestamped backup"""
        try:
            if os.path.exists(DATA_FILE):
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_file = os.path.join(BACKUP_DIR, f"backup_{timestamp}.json")
                shutil.copy2(DATA_FILE, backup_file)
                self.cleanup_old_backups()
        except Exception:
            pass
    
    def cleanup_old_backups(self):
        """Keep only last MAX_BACKUPS backups"""
        try:
            backups = sorted([f for f in os.listdir(BACKUP_DIR) if f.endswith('.json')])
            while len(backups) > MAX_BACKUPS:
                os.remove(os.path.join(BACKUP_DIR, backups.pop(0)))
        except Exception:
            pass
    
    def validate_input(self, prompt, field_type='text', required=True):
        """Validate user input based on field type"""
        while True:
            value = input(f"{COLORS['CYAN']}{prompt}{COLORS['END']}").strip()
            
            if not value and not required:
                return value
            
            if not value and required:
                print(self.colorize("⚠️  This field is required!", 'YELLOW'))
                continue
            
            if field_type == 'number':
                try:
                    return float(value)
                except ValueError:
                    print(self.colorize("⚠️  Please enter a valid number!", 'YELLOW'))
            elif field_type == 'int':
                try:
                    return int(value)
                except ValueError:
                    print(self.colorize("⚠️  Please enter a valid integer!", 'YELLOW'))
            elif field_type == 'date':
                try:
                    datetime.strptime(value, "%Y-%m-%d")
                    return value
                except ValueError:
                    print(self.colorize("⚠️  Please enter date in YYYY-MM-DD format!", 'YELLOW'))
            elif field_type == 'rating':
                try:
                    rating = int(value)
                    if 1 <= rating <= 5:
                        return rating
                    print(self.colorize("⚠️  Rating must be between 1-5!", 'YELLOW'))
                except ValueError:
                    print(self.colorize("⚠️  Please enter a valid number!", 'YELLOW'))
            else:
                return value
    
    def display_header(self):
        """Display animated app header"""
        os.system('cls' if os.name == 'nt' else 'clear')
        
        # Rainbow border top
        print(rainbow_border(70))
        
        # Animated title
        title = "🎯 PERSONAL TRACKER CLI 🎯"
        print(f"\n{COLORS['BOLD']}{COLORS['CYAN']}", end='')
        for i, char in enumerate(title):
            color = GRADIENT[i % len(GRADIENT)]
            sys.stdout.write(f"{color}{char}")
            sys.stdout.flush()
            time.sleep(0.02)
        print(f"{COLORS['END']}\n")
        
        # User greeting with sparkle
        username = self.settings['user']
        print(f"{COLORS['MAGENTA']}{ICONS['star']} Welcome back, {COLORS['BOLD']}{username}! {ICONS['star']}{COLORS['END']}")
        
        # Rainbow border
        print(rainbow_border(70))
        
        # Quote of the day
        quote = QUOTES[hash(datetime.now().strftime("%Y-%m-%d")) % len(QUOTES)]
        print(f"\n{COLORS['YELLOW']}{ICONS['sparkles']} {quote}{COLORS['END']}\n")
        
        # Stats bar
        total_entries = sum(len(self.data.get(t, [])) for t in TRACKERS.keys())
        print(f"{COLORS['GREEN']}{ICONS['fire']} Total Entries: {total_entries}  ", end='')
        print(f"{ICONS['trophy']} Trackers Active: {sum(1 for t in TRACKERS if len(self.data.get(t, [])) > 0)}{COLORS['END']}")
        
        print(rainbow_border(70))
        print()
    
    def display_menu(self):
        """Display colorful main menu"""
        menu_items = [
            ("1", "➕", "Add Entry", "GREEN"),
            ("2", "📋", "List Entries", "CYAN"),
            ("3", "✏️", "Update Entry", "YELLOW"),
            ("4", "🗑️", "Delete Entry", "RED"),
            ("5", "🔍", "Search / Filter", "MAGENTA"),
            ("6", "📊", "Analyze / Insights", "BLUE"),
            ("7", "📤", "Export / Backup", "CYAN"),
            ("8", "⏱", "Focus Mode", "YELLOW"),
            ("9", "🎨", "Settings", "MAGENTA"),
            ("0", "🚪", "Exit", "RED"),
        ]
        
        for num, icon, text, color in menu_items:
            print(f"{COLORS['BOLD']}{num}.{COLORS['END']}  {icon}  {COLORS[color]}{text}{COLORS['END']}")
        
        print(f"\n{COLORS['CYAN']}{ICONS['lightning']} Quick commands: {COLORS['YELLOW']}'add habit', 'list expenses', 'analyze mood'{COLORS['END']}")
        print(rainbow_border(70))
    
    def parse_quick_command(self, cmd):
        """Parse quick commands like 'add habit' or 'list expenses'"""
        cmd = cmd.lower().strip()
        
        patterns = [
            (r'^add (\w+)$', 'add'),
            (r'^list (\w+)$', 'list'),
            (r'^analyze (\w+)$', 'analyze'),
            (r'^delete (\w+)$', 'delete'),
            (r'^search (\w+)$', 'search'),
        ]
        
        for pattern, action in patterns:
            match = re.match(pattern, cmd)
            if match:
                tracker = match.group(1)
                if tracker in TRACKERS:
                    return action, tracker
        
        return None, None
    
    def add_entry(self, tracker_type=None):
        """Add new entry to specified tracker"""
        if not tracker_type:
            print(self.colorize(f"\n{ICONS['sparkles']} Available Trackers:", 'CYAN'))
            print(rainbow_border(70))
            
            for i, (key, value) in enumerate(TRACKERS.items(), 1):
                icon = TRACKERS[key]['icon']
                count = len(self.data.get(key, []))
                color = GRADIENT[i % len(GRADIENT)]
                print(f"{color}{i:2d}. {icon} {value['name']} ({count} entries){COLORS['END']}")
            
            print(rainbow_border(70))
            choice = input(f"\n{COLORS['CYAN']}Select tracker (number or name): {COLORS['END']}").strip().lower()
            
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(TRACKERS):
                    tracker_type = list(TRACKERS.keys())[idx]
            except ValueError:
                if choice in TRACKERS:
                    tracker_type = choice
                else:
                    error_animation("Invalid tracker!")
                    input("\nPress Enter to continue...")
                    return
        
        if tracker_type not in TRACKERS:
            error_animation("Invalid tracker!")
            input("\nPress Enter to continue...")
            return
        
        tracker = TRACKERS[tracker_type]
        loading_animation(f"Preparing {tracker['name']}")
        
        print(self.colorize(f"\n{ICONS['sparkles']} Adding to {tracker['name']}", 'GREEN'))
        print(rainbow_border(70))
        
        entry = {'id': self._generate_id(tracker_type), 'created_at': datetime.now().isoformat()}
        
        for field in tracker['fields']:
            prompt = f"{ICONS['arrow']} Enter {field}: "
            
            if field in ['hours', 'duration', 'calories', 'amount', 'spent', 'saved', 'budget']:
                entry[field] = self.validate_input(prompt, 'number')
            elif field in ['progress', 'attempts']:
                entry[field] = self.validate_input(prompt, 'int')
            elif field in ['date', 'deadline', 'fix_date']:
                default_date = datetime.now().strftime("%Y-%m-%d")
                entry[field] = self.validate_input(f"{prompt}[{default_date}]: ", 'date', required=False) or default_date
            elif field in ['quality', 'focus', 'rating']:
                entry[field] = self.validate_input(prompt, 'rating')
            elif field in ['completed', 'purchased', 'reminder']:
                val = input(f"{COLORS['CYAN']}{prompt}(yes/no): {COLORS['END']}").strip().lower()
                entry[field] = val in ['yes', 'y', 'true', '1']
            else:
                entry[field] = self.validate_input(prompt)
        
        if tracker_type not in self.data:
            self.data[tracker_type] = []
        
        self.data[tracker_type].append(entry)
        
        if self.save_data():
            success_animation(f"Entry added successfully! ID: {entry['id']}")
            self.log_action(f"Added entry to {tracker_type}: {entry['id']}")
            rocket_launch()
        
        input("\nPress Enter to continue...")
    
    def list_entries(self, tracker_type=None, entries=None):
        """List all entries for a tracker"""
        if not tracker_type:
            print(self.colorize(f"\n{ICONS['sparkles']} Available Trackers:", 'CYAN'))
            print(rainbow_border(70))
            
            for i, (key, value) in enumerate(TRACKERS.items(), 1):
                icon = TRACKERS[key]['icon']
                count = len(self.data.get(key, []))
                color = GRADIENT[i % len(GRADIENT)]
                print(f"{color}{i:2d}. {icon} {value['name']} ({count} entries){COLORS['END']}")
            
            print(rainbow_border(70))
            choice = input(f"\n{COLORS['CYAN']}Select tracker (number or name): {COLORS['END']}").strip().lower()
            
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(TRACKERS):
                    tracker_type = list(TRACKERS.keys())[idx]
            except ValueError:
                if choice in TRACKERS:
                    tracker_type = choice
                else:
                    error_animation("Invalid tracker!")
                    input("\nPress Enter to continue...")
                    return
        
        if tracker_type not in TRACKERS:
            error_animation("Invalid tracker!")
            input("\nPress Enter to continue...")
            return
        
        if entries is None:
            entries = self.data.get(tracker_type, [])
        
        if not entries:
            print(self.colorize(f"\n📭 No entries in {TRACKERS[tracker_type]['name']}", 'YELLOW'))
            input("\nPress Enter to continue...")
            return
        
        loading_animation("Loading entries")
        
        icon = TRACKERS[tracker_type]['icon']
        print(f"\n{COLORS['BOLD']}{COLORS['CYAN']}{icon} {TRACKERS[tracker_type]['name']}{COLORS['END']}")
        print(rainbow_border(70))
        
        for idx, entry in enumerate(entries, 1):
            # Colorful entry header
            color = GRADIENT[idx % len(GRADIENT)]
            print(f"\n{color}{COLORS['BOLD']}Entry #{idx}{COLORS['END']} {COLORS['MAGENTA']}(ID: {entry.get('id', 'N/A')}){COLORS['END']}")
            
            for field in TRACKERS[tracker_type]['fields']:
                value = entry.get(field, 'N/A')
                
                if field == 'progress' and isinstance(value, (int, float)):
                    bar = self._create_progress_bar(value)
                    print(f"  {COLORS['YELLOW']}{field}:{COLORS['END']} {value}% {bar}")
                elif field in ['completed', 'purchased', 'reminder'] and isinstance(value, bool):
                    status = f"{COLORS['GREEN']}✓ Yes{COLORS['END']}" if value else f"{COLORS['RED']}✗ No{COLORS['END']}"
                    print(f"  {COLORS['YELLOW']}{field}:{COLORS['END']} {status}")
                else:
                    print(f"  {COLORS['YELLOW']}{field}:{COLORS['END']} {COLORS['WHITE']}{value}{COLORS['END']}")
            
            print(f"{color}{'─' * 70}{COLORS['END']}")
        
        print(f"\n{COLORS['GREEN']}{ICONS['check']} Total entries: {len(entries)}{COLORS['END']}")
        input("\nPress Enter to continue...")
    
    def update_entry(self, tracker_type=None):
        """Update an existing entry"""
        if not tracker_type:
            tracker_type = self._select_tracker()
            if not tracker_type:
                return
        
        entries = self.data.get(tracker_type, [])
        if not entries:
            print(self.colorize(f"\n📭 No entries in {TRACKERS[tracker_type]['name']}", 'YELLOW'))
            input("\nPress Enter to continue...")
            return
        
        self.list_entries(tracker_type, entries)
        
        try:
            entry_id = input(f"\n{COLORS['CYAN']}Enter entry ID to update: {COLORS['END']}").strip()
            entry_idx = None
            
            for idx, entry in enumerate(entries):
                if entry.get('id') == entry_id:
                    entry_idx = idx
                    break
            
            if entry_idx is None:
                error_animation("Entry not found!")
                input("\nPress Enter to continue...")
                return
            
            self.undo_stack.append(('update', tracker_type, entry_idx, entries[entry_idx].copy()))
            
            print(self.colorize(f"\n{ICONS['sparkles']} Updating entry (press Enter to keep current value)", 'GREEN'))
            print(rainbow_border(70))
            
            for field in TRACKERS[tracker_type]['fields']:
                current_value = entries[entry_idx].get(field, '')
                prompt = f"{ICONS['arrow']} {field} [{COLORS['MAGENTA']}{current_value}{COLORS['END']}]: "
                
                new_value = input(f"{COLORS['CYAN']}{prompt}{COLORS['END']}").strip()
                if new_value:
                    if field in ['hours', 'duration', 'calories', 'amount', 'spent', 'saved', 'budget']:
                        try:
                            entries[entry_idx][field] = float(new_value)
                        except ValueError:
                            print(self.colorize("⚠️  Invalid number, keeping current value", 'YELLOW'))
                    elif field in ['progress', 'attempts']:
                        try:
                            entries[entry_idx][field] = int(new_value)
                        except ValueError:
                            print(self.colorize("⚠️  Invalid integer, keeping current value", 'YELLOW'))
                    elif field in ['completed', 'purchased', 'reminder']:
                        entries[entry_idx][field] = new_value.lower() in ['yes', 'y', 'true', '1']
                    else:
                        entries[entry_idx][field] = new_value
            
            entries[entry_idx]['updated_at'] = datetime.now().isoformat()
            
            if self.save_data():
                success_animation("Entry updated successfully!")
                self.log_action(f"Updated entry in {tracker_type}: {entry_id}")
        
        except Exception as e:
            error_animation(f"Error updating entry: {e}")
        
        input("\nPress Enter to continue...")
    
    def delete_entry(self, tracker_type=None):
        """Delete an entry"""
        if not tracker_type:
            tracker_type = self._select_tracker()
            if not tracker_type:
                return
        
        entries = self.data.get(tracker_type, [])
        if not entries:
            print(self.colorize(f"\n📭 No entries in {TRACKERS[tracker_type]['name']}", 'YELLOW'))
            input("\nPress Enter to continue...")
            return
        
        self.list_entries(tracker_type, entries)
        
        try:
            entry_id = input(f"\n{COLORS['CYAN']}Enter entry ID to delete: {COLORS['END']}").strip()
            entry_idx = None
            
            for idx, entry in enumerate(entries):
                if entry.get('id') == entry_id:
                    entry_idx = idx
                    break
            
            if entry_idx is None:
                error_animation("Entry not found!")
                input("\nPress Enter to continue...")
                return
            
            confirm = input(f"{COLORS['RED']}Are you sure you want to delete this entry? (yes/no): {COLORS['END']}").strip().lower()
            if confirm in ['yes', 'y']:
                self.undo_stack.append(('delete', tracker_type, entry_idx, entries[entry_idx].copy()))
                
                deleted = entries.pop(entry_idx)
                
                if self.save_data():
                    success_animation("Entry deleted successfully!")
                    self.log_action(f"Deleted entry from {tracker_type}: {entry_id}")
            else:
                print(self.colorize("❌ Deletion cancelled", 'YELLOW'))
        
        except Exception as e:
            error_animation(f"Error deleting entry: {e}")
        
        input("\nPress Enter to continue...")
    
    def search_entries(self, tracker_type=None):
        """Search and filter entries"""
        if not tracker_type:
            tracker_type = self._select_tracker()
            if not tracker_type:
                return
        
        entries = self.data.get(tracker_type, [])
        if not entries:
            print(self.colorize(f"\n📭 No entries in {TRACKERS[tracker_type]['name']}", 'YELLOW'))
            input("\nPress Enter to continue...")
            return
        
        print(self.colorize(f"\n{ICONS['sparkles']} Search Options:", 'CYAN'))
        print(rainbow_border(70))
        print(f"{COLORS['GREEN']}1. Search by keyword{COLORS['END']}")
        print(f"{COLORS['YELLOW']}2. Filter by date range{COLORS['END']}")
        print(f"{COLORS['MAGENTA']}3. Filter by field value{COLORS['END']}")
        print(rainbow_border(70))
        
        choice = input(f"\n{COLORS['CYAN']}Select option: {COLORS['END']}").strip()
        
        filtered_entries = []
        
        if choice == '1':
            keyword = input(f"{COLORS['CYAN']}Enter keyword: {COLORS['END']}").strip().lower()
            loading_animation("Searching")
            for entry in entries:
                for value in entry.values():
                    if keyword in str(value).lower():
                        filtered_entries.append(entry)
                        break
        
        elif choice == '2':
            start_date = input(f"{COLORS['CYAN']}Start date (YYYY-MM-DD) or 'today': {COLORS['END']}").strip().lower()
            end_date = input(f"{COLORS['CYAN']}End date (YYYY-MM-DD) or 'today': {COLORS['END']}").strip().lower()
            
            if start_date == 'today':
                start_date = datetime.now().strftime("%Y-%m-%d")
            if end_date == 'today':
                end_date = datetime.now().strftime("%Y-%m-%d")
            
            loading_animation("Filtering by date")
            for entry in entries:
                entry_date = entry.get('date', entry.get('created_at', ''))[:10]
                if start_date <= entry_date <= end_date:
                    filtered_entries.append(entry)
        
        elif choice == '3':
            field = input(f"{COLORS['CYAN']}Enter field name: {COLORS['END']}").strip()
            value = input(f"{COLORS['CYAN']}Enter value to filter: {COLORS['END']}").strip().lower()
            
            loading_animation("Filtering")
            for entry in entries:
                if str(entry.get(field, '')).lower() == value:
                    filtered_entries.append(entry)
        
        else:
            error_animation("Invalid option!")
            input("\nPress Enter to continue...")
            return
        
        if filtered_entries:
            success_animation(f"Found {len(filtered_entries)} matching entries")
            self.list_entries(tracker_type, filtered_entries)
        else:
            print(self.colorize("\n❌ No matching entries found", 'YELLOW'))
            input("\nPress Enter to continue...")
    
    def analyze_data(self, tracker_type=None):
        """Provide insights and analytics"""
        if not tracker_type:
            tracker_type = self._select_tracker()
            if not tracker_type:
                return
        
        entries = self.data.get(tracker_type, [])
        if not entries:
            print(self.colorize(f"\n📭 No entries to analyze in {TRACKERS[tracker_type]['name']}", 'YELLOW'))
            input("\nPress Enter to continue...")
            return
        
        loading_animation("Analyzing data")
        
        icon = TRACKERS[tracker_type]['icon']
        print(f"\n{COLORS['BOLD']}{COLORS['CYAN']}{icon} Analysis for {TRACKERS[tracker_type]['name']}{COLORS['END']}")
        print(rainbow_border(70))
        
        print(f"\n{COLORS['GREEN']}{ICONS['fire']} Total Entries: {COLORS['BOLD']}{len(entries)}{COLORS['END']}")
        
        if tracker_type == 'learning':
            self._analyze_learning(entries)
        elif tracker_type == 'expense':
            self._analyze_expenses(entries)
        elif tracker_type == 'mood':
            self._analyze_mood(entries)
        elif tracker_type == 'habit':
            self._analyze_habits(entries)
        elif tracker_type == 'fitness':
            self._analyze_fitness(entries)
        elif tracker_type == 'goal':
            self._analyze_goals(entries)
        elif tracker_type == 'task':
            self._analyze_tasks(entries)
        elif tracker_type == 'time':
            self._analyze_time(entries)
        else:
            print(self.colorize(f"\n{ICONS['sparkles']} Basic statistics shown above", 'YELLOW'))
        
        self._provide_suggestions(tracker_type, entries)
        
        input("\nPress Enter to continue...")
    
    def _analyze_learning(self, entries):
        """Analyze learning tracker data"""
        total_hours = sum(float(e.get('hours', 0)) for e in entries)
        subjects = {}
        
        for entry in entries:
            subject = entry.get('subject', 'Unknown')
            subjects[subject] = subjects.get(subject, 0) + float(entry.get('hours', 0))
        
        print(f"\n{COLORS['YELLOW']}{ICONS['time']} Total Study Hours: {COLORS['BOLD']}{total_hours:.1f}{COLORS['END']}")
        print(f"{COLORS['CYAN']}{ICONS['learning']} Subjects Covered: {COLORS['BOLD']}{len(subjects)}{COLORS['END']}")
        
        if subjects:
            print(f"\n{COLORS['MAGENTA']}{ICONS['sparkles']} Hours by Subject:{COLORS['END']}")
            for subject, hours in sorted(subjects.items(), key=lambda x: x[1], reverse=True):
                bar = self._create_bar_chart(hours, max(subjects.values()))
                print(f"  {COLORS['CYAN']}{subject}:{COLORS['END']} {COLORS['YELLOW']}{hours:.1f}h{COLORS['END']} {COLORS['GREEN']}{bar}{COLORS['END']}")
    
    def _analyze_expenses(self, entries):
        """Analyze expense tracker data"""
        total = sum(float(e.get('amount', 0)) for e in entries)
        categories = defaultdict(float)
        
        for entry in entries:
            category = entry.get('category', 'Other')
            categories[category] += float(entry.get('amount', 0))
        
        print(f"\n{COLORS['RED']}{ICONS['expense']} Total Expenses: {COLORS['BOLD']}${total:.2f}{COLORS['END']}")
        print(f"{COLORS['CYAN']}{ICONS['target']} Categories: {COLORS['BOLD']}{len(categories)}{COLORS['END']}")
        
        if total > 0:
            print(f"\n{COLORS['MAGENTA']}{ICONS['sparkles']} Expenses by Category:{COLORS['END']}")
            for category, amount in sorted(categories.items(), key=lambda x: x[1], reverse=True):
                percentage = (amount / total) * 100
                bar = self._create_bar_chart(amount, total)
                print(f"  {COLORS['CYAN']}{category}:{COLORS['END']} {COLORS['YELLOW']}${amount:.2f}{COLORS['END']} ({percentage:.1f}%) {COLORS['GREEN']}{bar}{COLORS['END']}")
        
        if entries:
            avg = total / len(entries)
            print(f"\n{COLORS['BLUE']}{ICONS['arrow']} Average Expense: {COLORS['BOLD']}${avg:.2f}{COLORS['END']}")
    
    def _analyze_mood(self, entries):
        """Analyze mood tracker data"""
        moods = defaultdict(int)
        
        for entry in entries:
            mood = entry.get('mood', 'Unknown')
            moods[mood] += 1
        
        print(f"\n{COLORS['MAGENTA']}{ICONS['sparkles']} Mood Distribution:{COLORS['END']}")
        for mood, count in sorted(moods.items(), key=lambda x: x[1], reverse=True):
            percentage = (count / len(entries)) * 100
            bar = self._create_bar_chart(count, len(entries))
            mood_color = 'GREEN' if 'happy' in mood.lower() else 'YELLOW' if 'neutral' in mood.lower() else 'RED'
            print(f"  {COLORS[mood_color]}{mood}:{COLORS['END']} {count} times ({percentage:.1f}%) {bar}")
        
        recent_entries = sorted(entries, key=lambda x: x.get('date', ''))[-7:]
        if recent_entries:
            happy_count = sum(1 for e in recent_entries if 'happy' in e.get('mood', '').lower())
            if happy_count >= len(recent_entries) * 0.6:
                pulse_text(f"\n{COLORS['GREEN']}{ICONS['fire']} You've been mostly happy this week! Keep it up!{COLORS['END']}", 2)
            elif happy_count < len(recent_entries) * 0.3:
                print(f"\n{COLORS['CYAN']}{ICONS['sparkles']} Tough week? Remember to take care of yourself.{COLORS['END']}")
    
    def _analyze_habits(self, entries):
        """Analyze habit tracker data"""
        habits = defaultdict(lambda: {'completed': 0, 'total': 0})
        
        for entry in entries:
            habit = entry.get('habit', 'Unknown')
            habits[habit]['total'] += 1
            if entry.get('completed', False):
                habits[habit]['completed'] += 1
        
        print(f"\n{COLORS['MAGENTA']}{ICONS['sparkles']} Habit Statistics:{COLORS['END']}")
        for habit, stats in habits.items():
            rate = (stats['completed'] / stats['total'] * 100) if stats['total'] > 0 else 0
            bar = self._create_progress_bar(rate)
            print(f"  {COLORS['CYAN']}{habit}:{COLORS['END']} {stats['completed']}/{stats['total']} ({rate:.1f}%) {bar}")
            
            streak = self._calculate_streak(entries, habit)
            if streak > 0:
                print(f"    {COLORS['YELLOW']}{ICONS['fire']} Current streak: {COLORS['BOLD']}{streak} days{COLORS['END']}")
    
    def _analyze_fitness(self, entries):
        """Analyze fitness tracker data"""
        total_duration = sum(float(e.get('duration', 0)) for e in entries)
        total_calories = sum(float(e.get('calories', 0)) for e in entries)
        
        print(f"\n{COLORS['GREEN']}{ICONS['fitness']} Total Workout Time: {COLORS['BOLD']}{total_duration:.0f} minutes{COLORS['END']}")
        print(f"{COLORS['RED']}{ICONS['fire']} Total Calories Burned: {COLORS['BOLD']}{total_calories:.0f}{COLORS['END']}")
        
        if entries:
            avg_duration = total_duration / len(entries)
            print(f"{COLORS['CYAN']}{ICONS['arrow']} Average Workout: {COLORS['BOLD']}{avg_duration:.1f} minutes{COLORS['END']}")
    
    def _analyze_goals(self, entries):
        """Analyze goal tracker data"""
        total_progress = sum(float(e.get('progress', 0)) for e in entries)
        completed = sum(1 for e in entries if float(e.get('progress', 0)) >= 100)
        
        print(f"\n{COLORS['GREEN']}{ICONS['trophy']} Completed Goals: {COLORS['BOLD']}{completed}/{len(entries)}{COLORS['END']}")
        if entries:
            avg_progress = total_progress / len(entries)
            bar = self._create_progress_bar(avg_progress)
            print(f"{COLORS['CYAN']}{ICONS['target']} Average Progress: {COLORS['BOLD']}{avg_progress:.1f}%{COLORS['END']} {bar}")
        
        categories = defaultdict(int)
        for entry in entries:
            cat = entry.get('category', 'Other')
            categories[cat] += 1
        
        print(f"\n{COLORS['MAGENTA']}{ICONS['sparkles']} Goals by Category:{COLORS['END']}")
        for cat, count in categories.items():
            print(f"  {COLORS['CYAN']}{cat}:{COLORS['END']} {COLORS['YELLOW']}{count} goals{COLORS['END']}")
    
    def _analyze_tasks(self, entries):
        """Analyze task tracker data"""
        statuses = defaultdict(int)
        priorities = defaultdict(int)
        
        for entry in entries:
            status = entry.get('status', 'Unknown')
            priority = entry.get('priority', 'Medium')
            statuses[status] += 1
            priorities[priority] += 1
        
        print(f"\n{COLORS['GREEN']}{ICONS['check']} Task Status:{COLORS['END']}")
        for status, count in statuses.items():
            percentage = (count / len(entries)) * 100
            bar = self._create_bar_chart(count, len(entries))
            print(f"  {COLORS['CYAN']}{status}:{COLORS['END']} {count} ({percentage:.1f}%) {COLORS['GREEN']}{bar}{COLORS['END']}")
        
        print(f"\n{COLORS['YELLOW']}{ICONS['target']} Task Priority:{COLORS['END']}")
        for priority, count in priorities.items():
            print(f"  {COLORS['CYAN']}{priority}:{COLORS['END']} {COLORS['YELLOW']}{count} tasks{COLORS['END']}")
    
    def _analyze_time(self, entries):
        """Analyze time tracker data"""
        total_time = sum(float(e.get('duration', 0)) for e in entries)
        categories = defaultdict(float)
        focus_scores = []
        
        for entry in entries:
            cat = entry.get('category', 'Other')
            duration = float(entry.get('duration', 0))
            categories[cat] += duration
            
            focus = entry.get('focus')
            if focus:
                focus_scores.append(int(focus))
        
        print(f"\n{COLORS['CYAN']}{ICONS['time']} Total Time Tracked: {COLORS['BOLD']}{total_time:.1f} hours{COLORS['END']}")
        
        if focus_scores:
            avg_focus = sum(focus_scores) / len(focus_scores)
            bar = self._create_progress_bar(avg_focus * 20)
            print(f"{COLORS['YELLOW']}{ICONS['target']} Average Focus Level: {COLORS['BOLD']}{avg_focus:.1f}/5{COLORS['END']} {bar}")
        
        print(f"\n{COLORS['MAGENTA']}{ICONS['sparkles']} Time by Category:{COLORS['END']}")
        for cat, time_spent in sorted(categories.items(), key=lambda x: x[1], reverse=True):
            percentage = (time_spent / total_time * 100) if total_time > 0 else 0
            bar = self._create_bar_chart(time_spent, total_time)
            print(f"  {COLORS['CYAN']}{cat}:{COLORS['END']} {COLORS['YELLOW']}{time_spent:.1f}h{COLORS['END']} ({percentage:.1f}%) {COLORS['GREEN']}{bar}{COLORS['END']}")
    
    def _provide_suggestions(self, tracker_type, entries):
        """Provide AI-like smart suggestions"""
        print(f"\n{COLORS['YELLOW']}{COLORS['BOLD']}{ICONS['lightning']} Smart Suggestions:{COLORS['END']}")
        print(rainbow_border(70))
        
        recent_days = 7
        recent_date = (datetime.now() - timedelta(days=recent_days)).strftime("%Y-%m-%d")
        recent_entries = [e for e in entries if e.get('date', e.get('created_at', ''))[:10] >= recent_date]
        
        if not recent_entries and len(entries) > 0:
            print(f"  {COLORS['RED']}{ICONS['cross']} No activity in the last {recent_days} days. Time to get back on track!{COLORS['END']}")
        elif len(recent_entries) > len(entries) * 0.7:
            pulse_text(f"  {COLORS['GREEN']}{ICONS['fire']} Great consistency! You're on fire!{COLORS['END']}", 2)
        
        if tracker_type == 'habit':
            incomplete = sum(1 for e in recent_entries if not e.get('completed', False))
            if incomplete > len(recent_entries) * 0.5:
                print(f"  {COLORS['YELLOW']}{ICONS['lightning']} Try focusing on one habit at a time to build momentum!{COLORS['END']}")
        
        elif tracker_type == 'expense':
            if len(recent_entries) >= 2:
                recent_total = sum(float(e.get('amount', 0)) for e in recent_entries[-7:])
                prev_entries = entries[:-7][-7:] if len(entries) > 7 else []
                prev_total = sum(float(e.get('amount', 0)) for e in prev_entries)
                
                if prev_total > 0 and recent_total > prev_total * 1.3:
                    increase = ((recent_total - prev_total) / prev_total) * 100
                    print(f"  {COLORS['RED']}{ICONS['expense']} Spending increased by {increase:.0f}% this week. Consider reviewing your budget!{COLORS['END']}")
        
        elif tracker_type == 'fitness':
            if len(recent_entries) < 3:
                print(f"  {COLORS['YELLOW']}{ICONS['fitness']} Try to exercise at least 3 times a week for better health!{COLORS['END']}")
        
        elif tracker_type == 'goal':
            low_progress = [e for e in entries if float(e.get('progress', 0)) < 25]
            if low_progress:
                print(f"  {COLORS['YELLOW']}{ICONS['target']} You have {len(low_progress)} goals with low progress. Break them into smaller tasks!{COLORS['END']}")
        
        elif tracker_type == 'task':
            pending = [e for e in entries if e.get('status', '').lower() in ['pending', 'todo', 'open']]
            if len(pending) > 10:
                print(f"  {COLORS['YELLOW']}{ICONS['task']} You have {len(pending)} pending tasks. Prioritize the top 3 for today!{COLORS['END']}")
        
        print(rainbow_border(70))
    
    def _calculate_streak(self, entries, habit):
        """Calculate current streak for a habit"""
        habit_entries = sorted([e for e in entries if e.get('habit') == habit], 
                              key=lambda x: x.get('date', ''), reverse=True)
        
        if not habit_entries:
            return 0
        
        streak = 0
        current_date = datetime.now().date()
        
        for entry in habit_entries:
            entry_date_str = entry.get('date', '')
            if not entry_date_str:
                continue
            
            try:
                entry_date = datetime.strptime(entry_date_str, "%Y-%m-%d").date()
                
                if entry_date == current_date and entry.get('completed', False):
                    streak += 1
                    current_date -= timedelta(days=1)
                elif entry_date < current_date:
                    break
            except ValueError:
                continue
        
        return streak
    
    def _create_progress_bar(self, progress, width=20):
        """Create colorful ASCII progress bar"""
        filled = int((progress / 100) * width)
        empty = width - filled
        
        if progress >= 75:
            color = COLORS['GREEN']
        elif progress >= 50:
            color = COLORS['YELLOW']
        elif progress >= 25:
            color = COLORS['MAGENTA']
        else:
            color = COLORS['RED']
        
        bar = f"{color}█{COLORS['END']}" * filled + f"{COLORS['WHITE']}░{COLORS['END']}" * empty
        return f"[{bar}]"
    
    def _create_bar_chart(self, value, max_value, width=30):
        """Create colorful bar chart"""
        if max_value == 0:
            return ""
        filled = int((value / max_value) * width)
        colors = [COLORS['GREEN'], COLORS['CYAN'], COLORS['YELLOW'], COLORS['MAGENTA']]
        bar = ""
        for i in range(filled):
            color = colors[i % len(colors)]
            bar += f"{color}▓{COLORS['END']}"
        return bar
    
    def _generate_id(self, tracker_type):
        """Generate unique ID for entry"""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        count = len(self.data.get(tracker_type, []))
        return f"{tracker_type[:3].upper()}{timestamp}{count:03d}"
    
    def _select_tracker(self):
        """Helper to select a tracker"""
        print(self.colorize(f"\n{ICONS['sparkles']} Available Trackers:", 'CYAN'))
        print(rainbow_border(70))
        
        for i, (key, value) in enumerate(TRACKERS.items(), 1):
            icon = TRACKERS[key]['icon']
            count = len(self.data.get(key, []))
            color = GRADIENT[i % len(GRADIENT)]
            print(f"{color}{i:2d}. {icon} {value['name']} ({count} entries){COLORS['END']}")
        
        print(rainbow_border(70))
        choice = input(f"\n{COLORS['CYAN']}Select tracker (number or name): {COLORS['END']}").strip().lower()
        
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(TRACKERS):
                return list(TRACKERS.keys())[idx]
        except ValueError:
            if choice in TRACKERS:
                return choice
        
        error_animation("Invalid tracker!")
        input("\nPress Enter to continue...")
        return None
    
    def export_data(self):
        """Export data in various formats"""
        print(self.colorize(f"\n{ICONS['sparkles']} Export Options:", 'CYAN'))
        print(rainbow_border(70))
        print(f"{COLORS['GREEN']}1. Export all data to JSON{COLORS['END']}")
        print(f"{COLORS['YELLOW']}2. Export summary report (TXT){COLORS['END']}")
        print(f"{COLORS['MAGENTA']}3. Export to CSV (select tracker){COLORS['END']}")
        print(f"{COLORS['CYAN']}4. Create monthly report{COLORS['END']}")
        print(rainbow_border(70))
        
        choice = input(f"\n{COLORS['CYAN']}Select option: {COLORS['END']}").strip()
        
        try:
            if choice == '1':
                loading_animation("Exporting to JSON")
                filename = f"export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                with open(filename, 'w', encoding='utf-8') as f:
                    json.dump(self.data, f, indent=2, ensure_ascii=False)
                success_animation(f"Exported to {filename}")
            
            elif choice == '2':
                loading_animation("Generating summary report")
                self._export_summary()
            
            elif choice == '3':
                self._export_csv()
            
            elif choice == '4':
                loading_animation("Creating monthly report")
                self._export_monthly_report()
            
            else:
                error_animation("Invalid option!")
        
        except Exception as e:
            error_animation(f"Export failed: {e}")
        
        input("\nPress Enter to continue...")
    
    def _export_summary(self):
        """Export summary report"""
        filename = "summary.txt"
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("=" * 70 + "\n")
            f.write("PERSONAL TRACKER - SUMMARY REPORT\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("=" * 70 + "\n\n")
            
            for tracker_type, tracker_info in TRACKERS.items():
                entries = self.data.get(tracker_type, [])
                f.write(f"\n{tracker_info['name']}: {len(entries)} entries\n")
                f.write("-" * 70 + "\n")
                
                if entries:
                    if tracker_type == 'expense':
                        total = sum(float(e.get('amount', 0)) for e in entries)
                        f.write(f"Total expenses: ${total:.2f}\n")
                    elif tracker_type == 'learning':
                        total_hours = sum(float(e.get('hours', 0)) for e in entries)
                        f.write(f"Total study hours: {total_hours:.1f}\n")
        
        success_animation(f"Summary exported to {filename}")
    
    def _export_csv(self):
        """Export tracker data to CSV"""
        tracker_type = self._select_tracker()
        if not tracker_type:
            return
        
        entries = self.data.get(tracker_type, [])
        if not entries:
            error_animation("No data to export!")
            return
        
        loading_animation("Exporting to CSV")
        filename = f"{tracker_type}_{datetime.now().strftime('%Y%m%d')}.csv"
        
        with open(filename, 'w', encoding='utf-8') as f:
            fields = TRACKERS[tracker_type]['fields']
            f.write(','.join(fields) + '\n')
            
            for entry in entries:
                values = [str(entry.get(field, '')).replace(',', ';') for field in fields]
                f.write(','.join(values) + '\n')
        
        success_animation(f"Exported to {filename}")
    
    def _export_monthly_report(self):
        """Export monthly report"""
        month = input(f"{COLORS['CYAN']}Enter month (YYYY-MM) or press Enter for current month: {COLORS['END']}").strip()
        if not month:
            month = datetime.now().strftime("%Y-%m")
        
        filename = f"monthly_report_{month}.txt"
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("=" * 70 + "\n")
            f.write(f"MONTHLY REPORT - {month}\n")
            f.write("=" * 70 + "\n\n")
            
            for tracker_type, tracker_info in TRACKERS.items():
                entries = self.data.get(tracker_type, [])
                monthly_entries = [e for e in entries if month in e.get('date', e.get('created_at', ''))]
                
                if monthly_entries:
                    f.write(f"\n{tracker_info['name']}: {len(monthly_entries)} entries\n")
                    f.write("-" * 70 + "\n")
        
        success_animation(f"Monthly report exported to {filename}")
    
    def focus_mode(self):
        """Pomodoro-style focus timer with animation"""
        print(self.colorize(f"\n{ICONS['time']} Focus Mode (Pomodoro Timer)", 'CYAN'))
        print(rainbow_border(70))
        
        try:
            duration = int(input(f"{COLORS['CYAN']}Enter focus duration in minutes [25]: {COLORS['END']}").strip() or "25")
            task = input(f"{COLORS['CYAN']}What are you working on? {COLORS['END']}").strip()
            
            loading_animation("Initializing Focus Mode")
            
            print(f"\n{COLORS['GREEN']}{COLORS['BOLD']}{ICONS['rocket']} Starting {duration}-minute focus session...{COLORS['END']}")
            print(f"{COLORS['YELLOW']}Press Ctrl+C to stop early{COLORS['END']}\n")
            
            start_time = time.time()
            end_time = start_time + (duration * 60)
            
            try:
                while time.time() < end_time:
                    remaining = int(end_time - time.time())
                    mins, secs = divmod(remaining, 60)
                    
                    # Animated timer display
                    frame = LOADING_FRAMES[int(time.time() * 2) % len(LOADING_FRAMES)]
                    progress = ((duration * 60 - remaining) / (duration * 60)) * 100
                    bar = self._create_progress_bar(progress)
                    
                    sys.stdout.write(f"\r{COLORS['CYAN']}{frame} {COLORS['BOLD']}⏱  {mins:02d}:{secs:02d}{COLORS['END']} {bar}")
                    sys.stdout.flush()
                    time.sleep(0.5)
                
                print(f"\n\n{COLORS['GREEN']}{COLORS['BOLD']}")
                sparkle_text("🎉 Focus session complete! Great work! 🎉", 0.05)
                print(COLORS['END'])
                rocket_launch()
                
                # Log to time tracker
                focus_rating = self.validate_input("Rate your focus (1-5): ", 'rating')
                
                entry = {
                    'id': self._generate_id('time'),
                    'task': task,
                    'duration': duration / 60,
                    'category': 'Focus Session',
                    'focus': focus_rating,
                    'created_at': datetime.now().isoformat()
                }
                
                if 'time' not in self.data:
                    self.data['time'] = []
                self.data['time'].append(entry)
                self.save_data()
                
                success_animation("Session logged to Time Tracker!")
            
            except KeyboardInterrupt:
                elapsed = int(time.time() - start_time) / 60
                print(f"\n\n{COLORS['YELLOW']}{ICONS['cross']} Session stopped early. You focused for {elapsed:.1f} minutes.{COLORS['END']}")
        
        except ValueError:
            error_animation("Invalid input!")
        except Exception as e:
            error_animation(f"Error: {e}")
        
        input("\nPress Enter to continue...")
    
    def settings_menu(self):
        """Settings and preferences with animations"""
        while True:
            self.display_header()
            print(self.colorize(f"{ICONS['sparkles']} Settings", 'CYAN'))
            print(rainbow_border(70))
            print(f"\n{COLORS['GREEN']}1. Change username (Current: {COLORS['BOLD']}{self.settings['user']}{COLORS['END']}{COLORS['GREEN']}){COLORS['END']}")
            print(f"{COLORS['YELLOW']}2. Change theme (Current: {COLORS['BOLD']}{self.settings['theme']}{COLORS['END']}{COLORS['YELLOW']}){COLORS['END']}")
            print(f"{COLORS['CYAN']}3. View statistics{COLORS['END']}")
            print(f"{COLORS['MAGENTA']}4. Backup data{COLORS['END']}")
            print(f"{COLORS['BLUE']}5. Restore from backup{COLORS['END']}")
            print(f"{COLORS['YELLOW']}6. Archive old entries{COLORS['END']}")
            print(f"{COLORS['GREEN']}7. Undo last action{COLORS['END']}")
            print(f"{COLORS['RED']}0. Back to main menu{COLORS['END']}")
            print(rainbow_border(70))
            
            choice = input(f"\n{COLORS['CYAN']}Select option: {COLORS['END']}").strip()
            
            if choice == '1':
                new_name = input(f"{COLORS['CYAN']}Enter new username: {COLORS['END']}").strip()
                if new_name:
                    loading_animation("Updating username")
                    self.settings['user'] = new_name
                    self.data['settings'] = self.settings
                    self.save_data()
                    success_animation("Username updated!")
                input("\nPress Enter to continue...")
            
            elif choice == '2':
                print(f"\n{COLORS['CYAN']}Themes: default, dark, light, no-color{COLORS['END']}")
                theme = input(f"{COLORS['CYAN']}Select theme: {COLORS['END']}").strip().lower()
                if theme in ['default', 'dark', 'light', 'no-color']:
                    loading_animation("Applying theme")
                    self.settings['theme'] = theme
                    self.data['settings'] = self.settings
                    self.save_data()
                    success_animation("Theme updated!")
                else:
                    error_animation("Invalid theme!")
                input("\nPress Enter to continue...")
            
            elif choice == '3':
                self._show_global_stats()
            
            elif choice == '4':
                loading_animation("Creating backup")
                self.create_backup()
                success_animation("Backup created!")
                input("\nPress Enter to continue...")
            
            elif choice == '5':
                self._restore_backup()
            
            elif choice == '6':
                self._archive_old_entries()
            
            elif choice == '7':
                self._undo_last_action()
            
            elif choice == '0':
                break
            
            else:
                error_animation("Invalid option!")
                input("\nPress Enter to continue...")
    
    def _show_global_stats(self):
        """Show overall statistics with animations"""
        loading_animation("Calculating statistics")
        
        print(self.colorize(f"\n{ICONS['trophy']} Global Statistics", 'CYAN'))
        print(rainbow_border(70))
        
        total_entries = sum(len(self.data.get(t, [])) for t in TRACKERS.keys())
        print(f"\n{COLORS['GREEN']}{ICONS['fire']} Total entries across all trackers: {COLORS['BOLD']}{total_entries}{COLORS['END']}")
        
        print(f"\n{COLORS['MAGENTA']}{ICONS['sparkles']} Entries by Tracker:{COLORS['END']}")
        for tracker_type, tracker_info in TRACKERS.items():
            count = len(self.data.get(tracker_type, []))
            if count > 0:
                icon = TRACKERS[tracker_type]['icon']
                bar = self._create_bar_chart(count, total_entries, 20)
                print(f"  {icon} {COLORS['CYAN']}{tracker_info['name']}:{COLORS['END']} {COLORS['YELLOW']}{count}{COLORS['END']} {bar}")
        
        try:
            size = os.path.getsize(DATA_FILE)
            print(f"\n{COLORS['BLUE']}{ICONS['target']} Data file size: {COLORS['BOLD']}{size / 1024:.2f} KB{COLORS['END']}")
        except:
            pass
        
        try:
            backups = [f for f in os.listdir(BACKUP_DIR) if f.endswith('.json')]
            print(f"{COLORS['CYAN']}{ICONS['arrow']} Backups available: {COLORS['BOLD']}{len(backups)}{COLORS['END']}")
        except:
            pass
        
        print(rainbow_border(70))
        input("\nPress Enter to continue...")
    
    def _restore_backup(self):
        """Restore from backup with animation"""
        try:
            backups = sorted([f for f in os.listdir(BACKUP_DIR) if f.endswith('.json')])
            
            if not backups:
                error_animation("No backups available!")
                input("\nPress Enter to continue...")
                return
            
            print(self.colorize(f"\n{ICONS['sparkles']} Available Backups:", 'CYAN'))
            print(rainbow_border(70))
            for i, backup in enumerate(backups[-10:], 1):
                print(f"{COLORS['CYAN']}{i}. {backup}{COLORS['END']}")
            print(rainbow_border(70))
            
            choice = input(f"\n{COLORS['CYAN']}Select backup to restore (number): {COLORS['END']}").strip()
            
            try:
                idx = int(choice) - 1
                if 0 <= idx < len(backups[-10:]):
                    backup_file = os.path.join(BACKUP_DIR, backups[-10:][idx])
                    
                    confirm = input(f"{COLORS['RED']}This will overwrite current data. Continue? (yes/no): {COLORS['END']}").strip().lower()
                    if confirm in ['yes', 'y']:
                        loading_animation("Restoring from backup")
                        with open(backup_file, 'r', encoding='utf-8') as f:
                            self.data = json.load(f)
                        self.save_data(create_backup=False)
                        success_animation("Data restored from backup!")
                        self.log_action(f"Restored from backup: {backups[-10:][idx]}")
                    else:
                        print(self.colorize("❌ Restore cancelled", 'YELLOW'))
                else:
                    error_animation("Invalid selection!")
            except ValueError:
                error_animation("Invalid input!")
        
        except Exception as e:
            error_animation(f"Error restoring backup: {e}")
        
        input("\nPress Enter to continue...")
    
    def _archive_old_entries(self):
        """Archive entries older than 30 days"""
        loading_animation("Scanning for old entries")
        
        cutoff_date = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
        archived_count = 0
        
        archive_data = {}
        
        for tracker_type in TRACKERS.keys():
            entries = self.data.get(tracker_type, [])
            old_entries = []
            new_entries = []
            
            for entry in entries:
                entry_date = entry.get('date', entry.get('created_at', ''))[:10]
                if entry_date < cutoff_date:
                    old_entries.append(entry)
                    archived_count += 1
                else:
                    new_entries.append(entry)
            
            if old_entries:
                archive_data[tracker_type] = old_entries
                self.data[tracker_type] = new_entries
        
        if archived_count > 0:
            try:
                existing_archive = {}
                if os.path.exists(ARCHIVE_FILE):
                    with open(ARCHIVE_FILE, 'r', encoding='utf-8') as f:
                        existing_archive = json.load(f)
                
                for tracker_type, entries in archive_data.items():
                    if tracker_type not in existing_archive:
                        existing_archive[tracker_type] = []
                    existing_archive[tracker_type].extend(entries)
                
                with open(ARCHIVE_FILE, 'w', encoding='utf-8') as f:
                    json.dump(existing_archive, f, indent=2, ensure_ascii=False)
                
                self.save_data()
                success_animation(f"Archived {archived_count} old entries!")
                self.log_action(f"Archived {archived_count} entries older than 30 days")
            except Exception as e:
                error_animation(f"Error archiving: {e}")
        else:
            print(self.colorize("ℹ️  No old entries to archive", 'YELLOW'))
        
        input("\nPress Enter to continue...")
    
    def _undo_last_action(self):
        """Undo the last delete or update action"""
        if not self.undo_stack:
            error_animation("Nothing to undo!")
            input("\nPress Enter to continue...")
            return
        
        action, tracker_type, idx, entry = self.undo_stack.pop()
        
        try:
            loading_animation("Undoing action")
            
            if action == 'delete':
                self.data[tracker_type].insert(idx, entry)
                success_animation("Delete action undone!")
            elif action == 'update':
                self.data[tracker_type][idx] = entry
                success_animation("Update action undone!")
            
            self.save_data()
            self.log_action(f"Undone {action} action in {tracker_type}")
        except Exception as e:
            error_animation(f"Error undoing action: {e}")
        
        input("\nPress Enter to continue...")
    
    def run(self):
        """Main application loop with splash screen"""
        # Animated splash screen
        os.system('cls' if os.name == 'nt' else 'clear')
        print("\n" * 5)
        sparkle_text("     🎯 PERSONAL TRACKER CLI 🎯", 0.08)
        print()
        typing_effect(f"          Version {VERSION}", 0.05)
        print()
        rocket_launch()
        loading_animation("Initializing", 2)
        
        while True:
            try:
                self.display_header()
                self.display_menu()
                
                choice = input(f"\n{COLORS['CYAN']}{COLORS['BOLD']}Enter your choice: {COLORS['END']}").strip()
                
                # Check for quick commands
                action, tracker = self.parse_quick_command(choice)
                if action:
                    loading_animation(f"Processing command")
                    if action == 'add':
                        self.add_entry(tracker)
                    elif action == 'list':
                        self.list_entries(tracker)
                    elif action == 'analyze':
                        self.analyze_data(tracker)
                    elif action == 'delete':
                        self.delete_entry(tracker)
                    elif action == 'search':
                        self.search_entries(tracker)
                    continue
                
                # Regular menu options
                if choice == '1':
                    self.add_entry()
                elif choice == '2':
                    self.list_entries()
                elif choice == '3':
                    self.update_entry()
                elif choice == '4':
                    self.delete_entry()
                elif choice == '5':
                    self.search_entries()
                elif choice == '6':
                    self.analyze_data()
                elif choice == '7':
                    self.export_data()
                elif choice == '8':
                    self.focus_mode()
                elif choice == '9':
                    self.settings_menu()
                elif choice == '0':
                    confirm = input(f"\n{COLORS['RED']}🚪 Are you sure you want to exit? (yes/no): {COLORS['END']}").strip().lower()
                    if confirm in ['yes', 'y']:
                        loading_animation("Saving data")
                        self.save_data()
                        print(f"\n{COLORS['CYAN']}{COLORS['BOLD']}")
                        sparkle_text("👋 Thanks for using Personal Tracker! Stay productive!", 0.05)
                        print(COLORS['END'])
                        rocket_launch()
                        break
                else:
                    error_animation("Invalid option! Please try again.")
                    input("\nPress Enter to continue...")
            
            except KeyboardInterrupt:
                print(f"\n\n{COLORS['YELLOW']}⚠️  Use option 0 to exit properly!{COLORS['END']}")
                input("\nPress Enter to continue...")
            except Exception as e:
                error_animation(f"Unexpected error: {e}")
                self.log_action(f"ERROR: {e}")
                input("\nPress Enter to continue...")

def main():
    """Application entry point"""
    try:
        tracker = PersonalTracker()
        tracker.run()
    except Exception as e:
        print(f"{COLORS['RED']}Fatal error: {e}{COLORS['END']}")
        sys.exit(1)

if __name__ == "__main__":
    main()